// Brand lockup: business logo bottom-left, Godrej signature bottom-right, same height, bottom-aligned.
/* eslint-disable @next/next/no-img-element */
export default function Footer() {
  return (
    <footer className="foot">
      <img src="/gcpl-logo.png" alt="Godrej Consumer Products" />
      <img src="/godrej-signature.png" alt="Godrej" />
    </footer>
  );
}
