'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import Footer from './Footer';

const UserCtx = createContext(null);
export const useUser = () => useContext(UserCtx);

export default function AppShell({ children, adminOnly = false }) {
  const [user, setUser] = useState(null);
  const router = useRouter();
  const path = usePathname();

  useEffect(() => {
    let off = false;
    fetch('/api/auth/me', { cache: 'no-store' })
      .then(async (r) => {
        if (r.status === 401) { router.replace('/login'); return; }
        const d = await r.json();
        if (off) return;
        if (adminOnly && d.user.role !== 'admin') { router.replace('/'); return; }
        setUser(d.user);
      })
      .catch(() => router.replace('/login'));
    return () => { off = true; };
  }, [adminOnly, router]);

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.replace('/login');
    router.refresh();
  }

  if (!user) return <div className="boot">Loading...</div>;
  const isAdmin = user.role === 'admin';
  const link = (href, label) => (
    <Link href={href} className={path === href ? 'on' : ''}>{label}</Link>
  );

  return (
    <UserCtx.Provider value={user}>
      <div className="shell">
        <header className="topbar">
          <h1>GCPL Complaint Analytics Dashboard</h1>
          <nav className="nav">
            {link('/', 'Dashboard')}
            {isAdmin && link('/admin/upload', 'Upload data')}
            {isAdmin && link('/admin/users', 'User management')}
          </nav>
          <div className="who">
            <span>{user.name || user.email}</span>
            <span className="role">{user.role}</span>
            <button className="btn ghost sm" onClick={logout}>Sign out</button>
          </div>
        </header>
        <main className="main">{children}</main>
        <Footer />
      </div>
    </UserCtx.Provider>
  );
}
