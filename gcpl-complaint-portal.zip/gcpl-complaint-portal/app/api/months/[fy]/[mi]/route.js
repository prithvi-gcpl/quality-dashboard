import { NextResponse } from 'next/server';
import { sql } from '@/lib/db';
import { guard, serverError } from '@/lib/auth';
import { FYS, OUT_COLS, MAX_PAYLOAD_BYTES } from '@/lib/constants';

export const dynamic = 'force-dynamic';

function parseKey(params) {
  const fy = parseInt(params.fy, 10);
  const mi = parseInt(params.mi, 10);
  if (!FYS.some((f) => f.id === fy) || !(mi >= 0 && mi <= 11)) return null;
  return { fy, mi };
}

// Any signed-in user can read a published month.
export async function GET(_req, { params }) {
  try {
    const { error } = await guard();
    if (error) return error;
    const k = parseKey(params);
    if (!k) return NextResponse.json({ error: 'Invalid month.' }, { status: 400 });
    const rows = await sql()`SELECT payload FROM month_data WHERE fy = ${k.fy} AND mi = ${k.mi}`;
    if (!rows[0]) return NextResponse.json({ error: 'No data for this month.' }, { status: 404 });
    return NextResponse.json(rows[0].payload, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    return serverError(e);
  }
}

// Admin only: publish (or replace) a month.
export async function PUT(req, { params }) {
  try {
    const { user, error } = await guard(true);
    if (error) return error;
    const k = parseKey(params);
    if (!k) return NextResponse.json({ error: 'Invalid month.' }, { status: 400 });

    const text = await req.text();
    if (text.length > MAX_PAYLOAD_BYTES) {
      return NextResponse.json({ error: 'File is too large for one month upload (limit ~4 MB after cleaning).' }, { status: 413 });
    }
    let body;
    try { body = JSON.parse(text); } catch { return NextResponse.json({ error: 'Invalid data.' }, { status: 400 }); }

    const { cols, rows } = body || {};
    if (!Array.isArray(cols) || cols.length !== OUT_COLS.length || cols.some((c, i) => c !== OUT_COLS[i])) {
      return NextResponse.json({ error: 'Unexpected column layout.' }, { status: 400 });
    }
    if (!Array.isArray(rows) || rows.length === 0) {
      return NextResponse.json({ error: 'No rows to publish.' }, { status: 400 });
    }
    if (rows.some((r) => !Array.isArray(r) || r.length !== cols.length)) {
      return NextResponse.json({ error: 'Malformed rows.' }, { status: 400 });
    }
    const ci = cols.indexOf('CLASSIFICATION');
    const complaints = rows.filter((r) => String(r[ci]).startsWith('COMPLAINT')).length;

    await sql()`INSERT INTO month_data (fy, mi, payload, total_rows, complaint_rows, uploaded_by, uploaded_at)
      VALUES (${k.fy}, ${k.mi}, ${JSON.stringify({ cols, rows })}::jsonb, ${rows.length}, ${complaints}, ${user.email}, now())
      ON CONFLICT (fy, mi) DO UPDATE SET
        payload = EXCLUDED.payload, total_rows = EXCLUDED.total_rows, complaint_rows = EXCLUDED.complaint_rows,
        uploaded_by = EXCLUDED.uploaded_by, uploaded_at = now()`;
    return NextResponse.json({ ok: true, total_rows: rows.length, complaint_rows: complaints });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(_req, { params }) {
  try {
    const { error } = await guard(true);
    if (error) return error;
    const k = parseKey(params);
    if (!k) return NextResponse.json({ error: 'Invalid month.' }, { status: 400 });
    await sql()`DELETE FROM month_data WHERE fy = ${k.fy} AND mi = ${k.mi}`;
    return NextResponse.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
