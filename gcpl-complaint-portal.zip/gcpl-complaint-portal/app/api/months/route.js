import { NextResponse } from 'next/server';
import { sql } from '@/lib/db';
import { guard, serverError } from '@/lib/auth';

export const dynamic = 'force-dynamic';

// Lists which months have been published (any signed-in user).
export async function GET() {
  try {
    const { error } = await guard();
    if (error) return error;
    const months = await sql()`SELECT fy, mi, total_rows, complaint_rows, uploaded_by, uploaded_at
                               FROM month_data ORDER BY fy, mi`;
    return NextResponse.json({ months }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    return serverError(e);
  }
}
