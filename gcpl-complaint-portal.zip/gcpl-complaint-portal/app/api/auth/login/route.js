import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql } from '@/lib/db';
import { ensureSetup } from '@/lib/setup';
import { createSession, serverError } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10); // keeps timing similar for unknown emails

export async function POST(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!email || !password) {
      return NextResponse.json({ error: 'Enter your email and password.' }, { status: 400 });
    }
    await ensureSetup();
    const q = sql();
    const rows = await q`SELECT id, email, name, role, active, password_hash FROM users WHERE email = ${email}`;
    const u = rows[0];
    const ok = await bcrypt.compare(password, u ? u.password_hash : DUMMY_HASH);
    if (!u || !ok) return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
    if (!u.active) {
      return NextResponse.json({ error: 'This account has been disabled. Contact the administrator.' }, { status: 403 });
    }
    await createSession(u);
    await q`UPDATE users SET last_login = now() WHERE id = ${u.id}`;
    return NextResponse.json({ ok: true, user: { id: u.id, email: u.email, name: u.name, role: u.role } });
  } catch (e) {
    return serverError(e);
  }
}
