import { NextResponse } from 'next/server';
import { guard, serverError } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const { user, error } = await guard();
    if (error) return error;
    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  } catch (e) {
    return serverError(e);
  }
}
