import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql } from '@/lib/db';
import { guard, serverError } from '@/lib/auth';

export const dynamic = 'force-dynamic';

async function otherActiveAdmins(q, id) {
  const r = await q`SELECT COUNT(*)::int AS n FROM users WHERE role = 'admin' AND active = TRUE AND id <> ${id}`;
  return r[0].n;
}

export async function PATCH(req, { params }) {
  try {
    const { user, error } = await guard(true);
    if (error) return error;
    const id = parseInt(params.id, 10);
    if (!id) return NextResponse.json({ error: 'Invalid user.' }, { status: 400 });
    const b = await req.json().catch(() => ({}));
    const q = sql();
    const found = await q`SELECT id, role, active FROM users WHERE id = ${id}`;
    const target = found[0];
    if (!target) return NextResponse.json({ error: 'User not found.' }, { status: 404 });

    const name = typeof b.name === 'string' ? b.name.trim().slice(0, 120) : null;
    const role = b.role === 'admin' || b.role === 'user' ? b.role : null;
    const active = typeof b.active === 'boolean' ? b.active : null;
    let hash = null;
    if (b.password !== undefined && b.password !== '') {
      if (String(b.password).length < 8) {
        return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 });
      }
      hash = await bcrypt.hash(String(b.password), 10);
    }

    const losesAdmin = target.role === 'admin' && target.active && ((role && role !== 'admin') || active === false);
    if (losesAdmin) {
      if (id === user.id) {
        return NextResponse.json({ error: 'You cannot remove your own admin access or disable yourself.' }, { status: 400 });
      }
      if ((await otherActiveAdmins(q, id)) === 0) {
        return NextResponse.json({ error: 'At least one active admin is required.' }, { status: 400 });
      }
    }
    if (id === user.id && active === false) {
      return NextResponse.json({ error: 'You cannot disable your own account.' }, { status: 400 });
    }

    const rows = await q`UPDATE users SET
        name = COALESCE(${name}, name),
        role = COALESCE(${role}, role),
        active = COALESCE(${active}, active),
        password_hash = COALESCE(${hash}, password_hash)
      WHERE id = ${id}
      RETURNING id, email, name, role, active, created_at, last_login`;
    return NextResponse.json({ user: rows[0] });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(_req, { params }) {
  try {
    const { user, error } = await guard(true);
    if (error) return error;
    const id = parseInt(params.id, 10);
    if (!id) return NextResponse.json({ error: 'Invalid user.' }, { status: 400 });
    if (id === user.id) return NextResponse.json({ error: 'You cannot delete your own account.' }, { status: 400 });
    const q = sql();
    const found = await q`SELECT role, active FROM users WHERE id = ${id}`;
    if (!found[0]) return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    if (found[0].role === 'admin' && found[0].active && (await otherActiveAdmins(q, id)) === 0) {
      return NextResponse.json({ error: 'At least one active admin is required.' }, { status: 400 });
    }
    await q`DELETE FROM users WHERE id = ${id}`;
    return NextResponse.json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
