import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql } from '@/lib/db';
import { guard, serverError } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function GET() {
  try {
    const { error } = await guard(true);
    if (error) return error;
    const users = await sql()`SELECT id, email, name, role, active, created_at, last_login FROM users ORDER BY created_at, id`;
    return NextResponse.json({ users });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req) {
  try {
    const { error } = await guard(true);
    if (error) return error;
    const b = await req.json().catch(() => ({}));
    const email = String(b.email || '').trim().toLowerCase();
    const name = String(b.name || '').trim().slice(0, 120);
    const password = String(b.password || '');
    const role = b.role === 'admin' ? 'admin' : 'user';
    if (!EMAIL_RE.test(email)) return NextResponse.json({ error: 'Enter a valid email address.' }, { status: 400 });
    if (password.length < 8) return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 });
    const hash = await bcrypt.hash(password, 10);
    try {
      const rows = await sql()`INSERT INTO users (email, name, password_hash, role)
        VALUES (${email}, ${name}, ${hash}, ${role})
        RETURNING id, email, name, role, active, created_at, last_login`;
      return NextResponse.json({ user: rows[0] }, { status: 201 });
    } catch (e) {
      if (String(e.message).includes('duplicate') || e.code === '23505') {
        return NextResponse.json({ error: 'A user with this email already exists.' }, { status: 409 });
      }
      throw e;
    }
  } catch (e) {
    return serverError(e);
  }
}
