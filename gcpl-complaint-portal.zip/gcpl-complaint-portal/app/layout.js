import './globals.css';

export const metadata = {
  title: 'GCPL Complaint Analytics',
  description: 'Godrej Consumer Products - Market Quality complaint analytics',
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
