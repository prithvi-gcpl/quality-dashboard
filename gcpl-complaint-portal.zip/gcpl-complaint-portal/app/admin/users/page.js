'use client';
import { useCallback, useEffect, useState } from 'react';
import AppShell, { useUser } from '@/components/AppShell';

const EMPTY = { id: null, email: '', name: '', password: '', role: 'user' };

function genPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const buf = new Uint32Array(12);
  crypto.getRandomValues(buf);
  return Array.from(buf, (n) => chars[n % chars.length]).join('');
}
const fmt = (d) => (d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : 'Never');

function Users() {
  const me = useUser();
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [showPw, setShowPw] = useState(true);
  const [msg, setMsg] = useState(null); // {type:'ok'|'err', text}
  const [busy, setBusy] = useState(false);
  const editing = form.id !== null;

  const load = useCallback(async () => {
    const r = await fetch('/api/users', { cache: 'no-store' });
    const d = await r.json();
    if (r.ok) setUsers(d.users); else setMsg({ type: 'err', text: d.error || 'Could not load users.' });
  }, []);
  useEffect(() => { load(); }, [load]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function save(e) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    const payload = editing
      ? { name: form.name, role: form.role, ...(form.password ? { password: form.password } : {}) }
      : { email: form.email, name: form.name, password: form.password, role: form.role };
    const r = await fetch(editing ? `/api/users/${form.id}` : '/api/users', {
      method: editing ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const d = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) { setMsg({ type: 'err', text: d.error || 'Could not save.' }); return; }
    setMsg({
      type: 'ok',
      text: editing
        ? `Updated ${form.email}.${form.password ? ' New password set.' : ''}`
        : `Added ${form.email}. Share the password with them securely: ${form.password}`,
    });
    setForm(EMPTY);
    load();
  }

  async function toggleActive(u) {
    setMsg(null);
    const r = await fetch(`/api/users/${u.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: !u.active }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) setMsg({ type: 'err', text: d.error || 'Could not update.' }); else load();
  }

  async function remove(u) {
    if (!confirm(`Delete ${u.email}? They will lose access immediately.`)) return;
    setMsg(null);
    const r = await fetch(`/api/users/${u.id}`, { method: 'DELETE' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) setMsg({ type: 'err', text: d.error || 'Could not delete.' }); else { setMsg({ type: 'ok', text: `Deleted ${u.email}.` }); load(); }
  }

  function startEdit(u) {
    setMsg(null);
    setForm({ id: u.id, email: u.email, name: u.name || '', password: '', role: u.role });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <>
      <div className="pagetitle">User management</div>
      <div className="pagesub">
        Add the email IDs that should have access and set the password each person will use to sign in.
        Everyone you add can view the dashboard. Only <b>admins</b> can upload data and manage users.
      </div>
      {msg && <div className={`msg ${msg.type}`}>{msg.text}</div>}

      <div className="split">
        <form className="panel" onSubmit={save}>
          <h2>{editing ? 'Edit user' : 'Add user'}</h2>
          <div className="field">
            <label>Email ID</label>
            <input type="email" required disabled={editing} value={form.email} onChange={set('email')} placeholder="name@company.com" />
          </div>
          <div className="field">
            <label>Name (optional)</label>
            <input value={form.name} onChange={set('name')} />
          </div>
          <div className="field">
            <label>{editing ? 'New password (leave blank to keep current)' : 'Password (min 8 characters)'}</label>
            <div className="pwrow">
              <input type={showPw ? 'text' : 'password'} required={!editing} minLength={form.password ? 8 : undefined}
                     autoComplete="new-password" value={form.password} onChange={set('password')} />
              <button type="button" className="btn ghost sm" onClick={() => setForm({ ...form, password: genPassword() })}>Generate</button>
            </div>
            <label className="checkrow" style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 400 }}>
              <input type="checkbox" style={{ width: 'auto', minWidth: 0 }} checked={showPw} onChange={(e) => setShowPw(e.target.checked)} /> Show password
            </label>
          </div>
          <div className="field">
            <label>Role</label>
            <select value={form.role} onChange={set('role')} disabled={editing && form.id === me.id}>
              <option value="user">User - can view the dashboard</option>
              <option value="admin">Admin - can also upload data and manage users</option>
            </select>
          </div>
          <div className="row-actions">
            <button className="btn" disabled={busy}>{busy ? 'Saving...' : editing ? 'Save changes' : 'Add user'}</button>
            {editing && <button type="button" className="btn ghost" onClick={() => setForm(EMPTY)}>Cancel</button>}
          </div>
        </form>

        <div className="panel">
          <h2>Users ({users.length})</h2>
          <div className="tbl-wrap">
            <table className="dt">
              <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last sign-in</th><th>Actions</th></tr></thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className={u.active ? '' : 'off'}>
                    <td>{u.name || <span className="muted">-</span>}</td>
                    <td>{u.email}{u.id === me.id && <span className="muted"> (you)</span>}</td>
                    <td><span className={`tag ${u.role === 'admin' ? 'fill' : ''}`}>{u.role}</span></td>
                    <td>{u.active ? 'Active' : 'Disabled'}</td>
                    <td>{fmt(u.last_login)}</td>
                    <td>
                      <div className="row-actions">
                        <button className="btn ghost sm" onClick={() => startEdit(u)}>Edit / reset password</button>
                        {u.id !== me.id && (
                          <>
                            <button className="btn ghost sm" onClick={() => toggleActive(u)}>{u.active ? 'Disable' : 'Enable'}</button>
                            <button className="btn ghost sm" onClick={() => remove(u)}>Delete</button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {!users.length && <tr><td colSpan={6} className="muted">No users yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}

export default function Page() {
  return <AppShell adminOnly><Users /></AppShell>;
}
