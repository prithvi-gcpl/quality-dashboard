'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import { FYS, MONTHS, MI2CAL, OUT_COLS, MAX_PAYLOAD_BYTES } from '@/lib/constants';
import { normalizeRows, filterToMonth } from '@/lib/normalize';

const fyLabel = (id) => (FYS.find((f) => f.id === id) || {}).label || id;
const fmt = (d) => (d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '-');

function Upload() {
  const inputRef = useRef(null);
  const [published, setPublished] = useState([]);
  const [file, setFile] = useState(null);
  const [parsed, setParsed] = useState(null); // {rows, summary}
  const [fy, setFy] = useState(2627);
  const [mi, setMi] = useState(0);
  const [dropOutside, setDropOutside] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const loadList = useCallback(async () => {
    const r = await fetch('/api/months', { cache: 'no-store' });
    const d = await r.json();
    if (r.ok) setPublished(d.months);
  }, []);
  useEffect(() => { loadList(); }, [loadList]);

  async function onFile(e) {
    const f = e.target.files[0];
    if (!f) return;
    setMsg(null); setParsed(null); setFile(f);
    try {
      const XLSX = await import('xlsx');
      const buf = await f.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array', cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { raw: true, defval: '' });
      if (!raw.length) throw new Error('The first sheet is empty.');
      const res = normalizeRows(raw);
      if (res.summary.missingCols.length > 8) {
        throw new Error('This does not look like the complaint report. Missing columns: ' + res.summary.missingCols.join(', '));
      }
      if (res.summary.suggested) { setFy(res.summary.suggested.fy); setMi(res.summary.suggested.mi); }
      setParsed(res);
    } catch (err) {
      setMsg({ type: 'err', text: 'Could not read the file: ' + err.message });
      setFile(null);
    }
  }

  const s = parsed && parsed.summary;
  const calMonth = MI2CAL[mi];
  const selectedKey = s && s.suggested ? s.suggested.key : null;
  const existing = published.find((m) => m.fy === fy && m.mi === mi);

  async function publish() {
    setBusy(true); setMsg(null);
    let rows = parsed.rows;
    if (dropOutside && selectedKey) rows = filterToMonth(rows, selectedKey);
    const body = JSON.stringify({ cols: OUT_COLS, rows });
    if (body.length > MAX_PAYLOAD_BYTES) {
      setBusy(false);
      setMsg({ type: 'err', text: `This month is too large to publish in one go (${(body.length / 1e6).toFixed(1)} MB, limit 4 MB). Split the file or remove unused rows.` });
      return;
    }
    const r = await fetch(`/api/months/${fy}/${mi}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body });
    const d = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) { setMsg({ type: 'err', text: d.error || 'Publish failed.' }); return; }
    setMsg({ type: 'ok', text: `Published ${MONTHS[mi]} ${fyLabel(fy)}: ${d.total_rows.toLocaleString()} rows (${d.complaint_rows.toLocaleString()} complaints). Everyone with access now sees it on the dashboard.` });
    setParsed(null); setFile(null); if (inputRef.current) inputRef.current.value = '';
    loadList();
  }

  async function remove(m) {
    if (!confirm(`Remove ${MONTHS[m.mi]} ${fyLabel(m.fy)} from the portal? The dashboard will no longer show it.`)) return;
    const r = await fetch(`/api/months/${m.fy}/${m.mi}`, { method: 'DELETE' });
    if (r.ok) { setMsg({ type: 'ok', text: `Removed ${MONTHS[m.mi]} ${fyLabel(m.fy)}.` }); loadList(); }
    else setMsg({ type: 'err', text: 'Could not remove.' });
  }

  return (
    <>
      <div className="pagetitle">Upload monthly data</div>
      <div className="pagesub">
        Upload the monthly complaint report (.xlsx or .csv). The file is cleaned automatically (spelling variants, state names,
        channel names and so on) and shown to you below before anything is published. Once you publish, every signed-in user sees the data
        on the dashboard. No upload is needed on their side.
      </div>
      {msg && <div className={`msg ${msg.type}`}>{msg.text}</div>}

      <div className="panel">
        <h2>1. Choose file</h2>
        <div className="drop" onClick={() => inputRef.current && inputRef.current.click()}>
          <b>{file ? file.name : 'Click to choose the monthly report'}</b>
          <div className="muted" style={{ marginTop: 4 }}>{file ? `${(file.size / 1024).toFixed(0)} KB` : 'Excel (.xlsx, .xls) or CSV. The first sheet is used.'}</div>
        </div>
        <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: 'none' }} onChange={onFile} />
      </div>

      {parsed && (
        <>
          <div className="panel">
            <h2>2. Check what was read</h2>
            <div>
              <div className="stat"><b>{s.total.toLocaleString()}</b><span>Rows</span></div>
              <div className="stat"><b>{s.complaints.toLocaleString()}</b><span>True complaints</span></div>
              <div className="stat"><b>{s.outside}</b><span>Rows dated outside the month</span></div>
              <div className="stat"><b>{s.noDate}</b><span>Rows with no date</span></div>
            </div>
            {s.missingCols.length > 0 && (
              <div className="msg">Columns not found (filled with NA): {s.missingCols.join(', ')}</div>
            )}
            {s.outside > 0 && (
              <label className="checkrow">
                <input type="checkbox" checked={dropOutside} onChange={(e) => setDropOutside(e.target.checked)} />
                Exclude the {s.outside} row(s) dated outside {MONTHS[(s.suggested ? s.suggested.mi : mi)]} (likely date typos). Otherwise they are kept in this month.
              </label>
            )}
            {s.changeList.length > 0 && (
              <>
                <div className="lbl" style={{ margin: '14px 0 6px' }}>Cleaning applied</div>
                <div className="tbl-wrap">
                  <table className="dt">
                    <thead><tr><th>Column</th><th>Cells changed</th><th>Most common changes</th></tr></thead>
                    <tbody>
                      {s.changeList.map((c) => (
                        <tr key={c.col}><td>{c.col}</td><td>{c.count.toLocaleString()}</td><td>{c.examples.join('  |  ')}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>

          <div className="panel">
            <h2>3. Publish</h2>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <div className="sg">
                <label>Financial year</label>
                <select className="sel" value={fy} onChange={(e) => setFy(parseInt(e.target.value, 10))}>
                  {FYS.map((f) => <option key={f.id} value={f.id}>{f.label} ({f.range})</option>)}
                </select>
              </div>
              <div className="sg">
                <label>Month</label>
                <select className="sel" value={mi} onChange={(e) => setMi(parseInt(e.target.value, 10))}>
                  {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
                </select>
              </div>
              <button className="btn" disabled={busy} onClick={publish}>
                {busy ? 'Publishing...' : existing ? 'Replace existing and publish' : 'Publish to portal'}
              </button>
            </div>
            <div className="muted" style={{ marginTop: 8 }}>
              Detected from the dates in the file: {s.suggested ? `${MONTHS[s.suggested.mi]} ${fyLabel(s.suggested.fy)}` : 'could not detect'}.
              Publishing to {MONTHS[mi]} {fyLabel(fy)} (calendar month {calMonth}).
            </div>
            {existing && (
              <div className="msg err">
                {MONTHS[mi]} {fyLabel(fy)} is already published ({existing.total_rows.toLocaleString()} rows, uploaded {fmt(existing.uploaded_at)} by {existing.uploaded_by}). Publishing will replace it.
              </div>
            )}
          </div>
        </>
      )}

      <div className="panel">
        <h2>Published months</h2>
        <div className="tbl-wrap">
          <table className="dt">
            <thead><tr><th>Month</th><th>Financial year</th><th>Rows</th><th>Complaints</th><th>Uploaded by</th><th>Uploaded at</th><th></th></tr></thead>
            <tbody>
              {published.map((m) => (
                <tr key={`${m.fy}-${m.mi}`}>
                  <td>{MONTHS[m.mi]}</td><td>{fyLabel(m.fy)}</td>
                  <td>{m.total_rows.toLocaleString()}</td><td>{m.complaint_rows.toLocaleString()}</td>
                  <td>{m.uploaded_by}</td><td>{fmt(m.uploaded_at)}</td>
                  <td><button className="btn ghost sm" onClick={() => remove(m)}>Remove</button></td>
                </tr>
              ))}
              {!published.length && <tr><td colSpan={7} className="muted">Nothing published yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <div style={{ marginTop: 10 }}><Link className="btn ghost sm" href="/">Open dashboard</Link></div>
      </div>
    </>
  );
}

export default function Page() {
  return <AppShell adminOnly><Upload /></AppShell>;
}
