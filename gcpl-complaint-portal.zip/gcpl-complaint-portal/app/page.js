'use client';
import { useEffect } from 'react';
import AppShell, { useUser } from '@/components/AppShell';
import { MARKUP } from '@/lib/dashboardMarkup';

function Dashboard() {
  const user = useUser();
  useEffect(() => {
    let ctl = null;
    let cancelled = false;
    import('@/lib/engine').then((m) => {
      if (!cancelled) ctl = m.startDashboard({ isAdmin: user.role === 'admin' });
    });
    return () => { cancelled = true; if (ctl) ctl.destroy(); };
  }, [user.role]);
  return <div dangerouslySetInnerHTML={{ __html: MARKUP }} />;
}

export default function Page() {
  return <AppShell><Dashboard /></AppShell>;
}
